package com.telstra.jwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtProjApplication.class, args);
	}

}

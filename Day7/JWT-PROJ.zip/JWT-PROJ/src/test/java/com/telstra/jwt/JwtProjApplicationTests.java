package com.telstra.jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtProjApplicationTests {

	@Test
	void contextLoads() {
	}

}
